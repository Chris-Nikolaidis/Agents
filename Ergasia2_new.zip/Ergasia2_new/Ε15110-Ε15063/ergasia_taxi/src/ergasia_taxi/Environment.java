/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ergasia_taxi;

/**
 *
 * @author Χρήστος
 */

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.domain.FIPAException;
import jade.lang.acl.ACLMessage;
import java.util.Arrays;
import java.util.Random;
import sun.management.resources.agent;


public class Environment extends Agent {
private int clients;// 4 clients in the environment
private String[] choose;//receive cost from agent
public int current;//current agent that is having a client
public int[] cost= new int[3];//keep agent's cost to get to client
private int min;
private String[] report;
private boolean contract;
private String[] agentArray;//array with all agents
private int numberOfAgents;
public int agents[]=new int[3];
//variables for getting taxi starting pos
public int tx;
public int ty;
public int pos;//taxi position
public int move=0;//flag variable
public int reward=0;//cost for the taxi
public int treward=0;//total reward for taxi
public int[] client= new int[10];//clients starting position and destination
public String [] clientchoose;//array that states which client was chosen by the taxi
public void setup()
	{

        try {Thread.sleep(50);} catch (InterruptedException ie) {}      //important
        //search the registry for agents
        DFAgentDescription template = new DFAgentDescription();
        ServiceDescription sd = new ServiceDescription();
        sd.setType("agent");
        template.addServices(sd);
        try {
            DFAgentDescription[] result = DFService.search(this, template);
            numberOfAgents = result.length;
            agentArray = new String[numberOfAgents];
            for (int i = 0; i < numberOfAgents; ++i) {
                agentArray[i] = result[i].getName().getLocalName();
            }
        }
        catch (FIPAException fe) {fe.printStackTrace();}
        Arrays.sort(agentArray);
        System.out.println("Found:");
        for (int i = 0; i < numberOfAgents; ++i) System.out.println(agentArray[i]);
        findStartingLocations();//random starting position for the 3 taxis
		
		
		
		addBehaviour(new CyclicBehaviour(this) {
            public void action(){
				
                                try {Thread.sleep(50);} catch (InterruptedException ie) {}//wait
                                //works for 4 clients
                               for(clients=0; clients<4; clients++)
                               {
                                   if(clients==0)
                                   {
                                       System.out.println("TaxiStartingPos");
                                       System.out.println("agent1: "+agents[0]);
                                       System.out.println("agent2: "+agents[1]);
                                       System.out.println("agent3: "+agents[2]);
                                   }
                                   else
                                   {
                                       System.out.println("agent1: "+agents[0]);
                                       System.out.println("agent2: "+agents[1]);
                                       System.out.println("agent3: "+agents[2]);
                                   }
                                   getclient();//get one client's start and dest
                                    //initiating cnp
                                    for (String agentName: agentArray) 
                                    {
                                        ACLMessage message = new ACLMessage(ACLMessage.INFORM);
                                        //refer to receiver by local name
                                        message.addReceiver(new AID(agentName, AID.ISLOCALNAME));
                                        //sending message with client position and destination
                                        //call for proposals
                                        message.setContent("Client Position and Destination,"+client[0]+","+client[1]);
                                        send(message);
                                        ACLMessage msg = null;
                                        //waiting for taxi to reply(bid)
                                        msg = blockingReceive();
                                        String[] choose=msg.getContent().split(",");
                                        if(agentName.equals("agent1"))//if agent1 was the one that bid
                                        {
                                            System.out.println("Agent1 steps");
                                            System.out.println(choose[1]);
                                            cost[0]= Integer.valueOf(choose[1]);//keep the bid in an array
                                        }
                                        if(agentName.equals("agent2"))//if agent2 was the one that bid
                                        {
                                            System.out.println("Agent2 steps");
                                            System.out.println(choose[1]);
                                            cost[1]= Integer.valueOf(choose[1]);//keep the bid in an array
                                        }
                                        if(agentName.equals("agent3"))//if agent3 was the one that bid
                                        {
                                            System.out.println("Agent3 steps");
                                            System.out.println(choose[1]);
                                            cost[2]= Integer.valueOf(choose[1]);//keep the bid in an array
                                        }
                                        
                                        
                                        
                                    }
                                    //finding best bid
                                        //best bid is the smaller steps required to reach the client
                                        for(int i=0; i<3; i++)
                                        {
                                            if(i==0)
                                            {
                                                min=i;
                                            }
                                            else
                                            {
                                                if(cost[i]<cost[0])
                                                {
                                                    min=i;
                                                }
                                            }
                                        }
                                    min=min+1;
                                    System.out.println("chosen Agent"+min);
                                    //announcements
                                    for (String agentName: agentArray) 
                                    {
                                        //if agent1 was chosen
                                        if(agentName.contains("1") && min==1) 
                                        {
                                            contract=true;
                                            current=1;
                                            ACLMessage message = new ACLMessage(ACLMessage.INFORM);
                                        //refer to receiver by local name
                                        message.addReceiver(new AID(agentName, AID.ISLOCALNAME));
                                        //sending message 
                                        message.setContent("Job assignment,"+contract);
                                        send(message);//informing taxi that it got the job
                                        }
                                        //if agent2 was chosen
                                        else if(agentName.contains("2") && min==2) 
                                        {
                                            contract=true;
                                            current=2;
                                            ACLMessage message = new ACLMessage(ACLMessage.INFORM);
                                        //refer to receiver by local name
                                        message.addReceiver(new AID(agentName, AID.ISLOCALNAME));
                                        //sending message 
                                        message.setContent("Job assignment,"+contract);
                                        send(message);//informing taxi that it got the job
                                        }
                                        //if agent3 was chosen
                                        else if(agentName.contains("3") && min==3) 
                                        {
                                            contract=true;
                                            current=3;
                                            ACLMessage message = new ACLMessage(ACLMessage.INFORM);
                                        //refer to receiver by local name
                                        message.addReceiver(new AID(agentName, AID.ISLOCALNAME));
                                        //sending message 
                                        message.setContent("Job assignment,"+contract);
                                        send(message);//informing taxi that it got the job
                                        } 
                                        //if the agent was not chosen
                                        else
                                        {
                                             contract=false;
                                            ACLMessage message = new ACLMessage(ACLMessage.INFORM);
                                        //refer to receiver by local name
                                        message.addReceiver(new AID(agentName, AID.ISLOCALNAME));
                                        //sending message 
                                        message.setContent("Job assignment,"+contract);
                                        send(message);//informing taxi that it got the job
                                        }
                                    }
                                    //waiting for response informing success or failure to deliver
                                     ACLMessage msg = null;
                                     msg = blockingReceive();
                                     if(msg.getContent().contains("Report,"))   
                                     {  
                                        
                                        String[] report = msg.getContent().split(",");
                                        if(report[2].equals("1"))//success
                                        {
                                        reward=reward+Integer.valueOf(report[1]);//keeping the cost
                                        }
                                        else
                                        {
                                            System.out.println("Failed to deliver.");
                                        }
                                     }
                                     //keeping agent's position
                                     if(current==1)
                                     {
                                         agents[0]=client[1];
                                         
                                     }
                                     if(current==2)
                                     {
                                         agents[1]=client[1];
                                         
                                     }
                                     if(current==3)
                                     {
                                         agents[2]=client[1];
                                         
                                     }
                                     
                               }
                               //calculating final reward and informing all agents
                               for (String agentName: agentArray) 
                                    {
                                        ACLMessage messageFinal = new ACLMessage(ACLMessage.INFORM);
                                        messageFinal.addReceiver(new AID(agentName, AID.ISLOCALNAME));
                                        System.out.println("Total Cost: "+reward);
                                        treward=80-reward;//calculate reward for taxi and send it
                                        messageFinal.setContent("End"+","+treward);
                                        send(messageFinal);
                                    }
                                    System.out.println(getLocalName()+" terminating");
                                    System.out.println("Good Job Everyone.");
                                    doDelete();
                                    System.exit(0); 
                              
                }		
		});

	}
	
	
	
    public void findStartingLocations()//randomly generated starting position for taxi
    {

        try {Thread.sleep(50);} catch (InterruptedException ie) {}

	for (String agentName: agentArray) 
	{
             tx =(int)(Math.random()*((5-0)))+0;//random number from 0 to 4
             ty=(int)(Math.random()*((5-0)))+0;//random number from 0 to 4
              pos=tx*10+ty;//agent position
              if(agentName.equals("agent1"))
              {
                
                agents[0]=pos;
              }
              if(agentName.equals("agent2"))
              {
               
                agents[1]=pos;
              }
               if(agentName.equals("agent3"))
              {
               
                agents[2]=pos;
              }
              ACLMessage message = new ACLMessage(ACLMessage.INFORM);
             //refer to receiver by local name
             message.addReceiver(new AID(agentName, AID.ISLOCALNAME));
             message.setContent("TaxiStartingPos,"+pos);
             send(message);
        }
    }
    
    public void getclient()//randomly generated starting position for client
    {
        int xx=-2;//flag variable
                                int yy=-2;//flag variable
				int clientstart;//client starting position
				int clientdest;//client destination
                                int flag=0;//flag variable 
        while(flag==0)//check if position is 00 or 03 or 40 or 44 were randomly generated
                                            {
                                                xx=(int)(Math.random()*((5-0)))+0;//random number from 0 to 4
                                                yy=(int)(Math.random()*((5-0)))+0;//random number from 0 to 4
                                                if(xx==0 && yy==0)//00
                                                {
                                                    flag=1;//end while
                                                }
                                                if(xx==0 && yy==3)//03
                                                {
                                                    flag=1;//end while
                                                }
                                                if(xx==4 && yy==0)//40
                                                {
                                                    flag=1;//end while
                                                }
                                                if(xx==4 && yy==4)//44
                                                {
                                                    flag=1;//end while
                                                }
                                            }
                                            flag=0;
                                            clientstart=xx*10+yy;//client starting pos
                                            while(flag==0)//check if position is 00 or 03 or 40 or 44 were randomly generated
                                            {
                                               xx=(int)(Math.random()*((5-0)))+0;//random number from 0 to 4
                                                yy=(int)(Math.random()*((5-0)))+0;//random number from 0 to 4
                                                if(xx==0 && yy==0)//00
                                                {
                                                    flag=1;//end while
                                                }
                                                if(xx==0 && yy==3)//03
                                                {
                                                    flag=1;//end while
                                                }
                                                if(xx==4 && yy==0)//40
                                                {
                                                    flag=1;//end while
                                                }
                                                if(xx==4 && yy==4)//44
                                                {
                                                    flag=1;//end while
                                                } 
                                            }
                                            clientdest=xx*10+yy;//client destination
                                            //keeping client coords in array
                                            System.out.println("client");
                                            System.out.println("Start "+clientstart);
                                            System.out.println("Dest "+clientdest);
                                            client[0]=clientstart;
                                            client[1]=clientdest;
                                           
    }
}

