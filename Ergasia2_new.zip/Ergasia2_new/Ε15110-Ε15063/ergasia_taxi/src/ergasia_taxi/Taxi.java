/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ergasia_taxi;

/**
 *
 * @author Χρήστος
 */
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.domain.FIPAException;
import jade.lang.acl.ACLMessage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Set;

public class Taxi extends Agent 
{
    public int reward=0;//save taxi's total reward
   
    //variable used in converting String to Int and used in sending messages to grid
    public String go;
    //variables used in converting String positions to Int and are used in getNodes(int x, int y) as parameters
    private int x1;
    private int x2;
    private int x3;
    public static int ar;
    private String[] agentpos;//keeps taxi's position
    private String[] clientpos;//keeps clients starting position and destination
    
    
    //variables used in getNodes(int x, int y)
    public  int start;
    public int goal;
    public int gx;
    public int gy;
    public String s;
    public String g;
    public Node nodes;
    public Node nodeg;
    //flag to check whether all clients have reached their destination
    public int end;
    //heuristic
    private  static int steps;//counts steps to go to client and drop him to the destination
    private String[] contract;//array that keeps whether the agent got the job
    private static int[] heuclients =new int[200];//save every client's steps
    //flag variables
    public static int gclient=-1;
    public static int dclient=-1;
    public static int fl=1;
    public static int client;
    //arrays that keep paths
    private static String[] goclient =new String[200];//path from taxi to client
    private static String[] dropclient =new String[200];//path when taxi has client, to the destination
    
    
   
   
    public void setup() 
    {

        // register agent to directory facilitator
        DFAgentDescription dfd = new DFAgentDescription();
        // agent id
        dfd.setName(getAID());
        ServiceDescription sd = new ServiceDescription();
        sd.setType("agent");
        sd.setName(getLocalName());
        dfd.addServices(sd);
        try {DFService.register(this, dfd);}
        catch (FIPAException fe) {fe.printStackTrace();}

        addBehaviour(new CyclicBehaviour(this) {
        public void action() 
        {

                ACLMessage msg = null;
                //waiting to receive message
                msg = blockingReceive();
                //agent starting position
                if(msg.getContent().contains("TaxiStartingPos,"))
                {
                    //agent position is kept in agentpos[1]
                  String[] agentpos= msg.getContent().split(",");                                   
                 // System.out.println("TaxiStartingPos");
                //  System.out.println(agentpos[1]);
                  x1=Integer.parseInt(agentpos[1]);
                }
                //agent receives client start and dest
                else if(msg.getContent().contains("Client Position and Destination,"))
                {
                   String[] clientpos = msg.getContent().split(",");
                   
                        x2=Integer.parseInt(clientpos[1]);
                        x3=Integer.parseInt(clientpos[2]);
                               
                           getNodes(x1,x2);
                           ACLMessage message = new ACLMessage(ACLMessage.INFORM);
                        message.addReceiver(new AID("grid", AID.ISLOCALNAME));
                         message.setContent("Steps,"+steps);
                         send(message);
                         
                          
                 }
                //announcement. agent learns whether he got the job or not
                else if(msg.getContent().contains("Job assignment,"))
                {
                    String[] contract= msg.getContent().split(","); 
                   // System.out.println("Job: "+contract[1]); 
                    if("true".equals(contract[1]))//the agent got the job.
                    {
                        
                              
                           getNodes(x2,x3);
                           System.out.println("Steps: "+heuclients[0]);
                           steps=heuclients[0]+2;//+2 is for pick and drop
                           ACLMessage message = new ACLMessage(ACLMessage.INFORM);
                           message.addReceiver(new AID("grid", AID.ISLOCALNAME));
                           message.setContent("Report"+","+steps+","+"1");//1 means successful delivery
                           send(message);
                           x1=x3;
                           for(int i=0; i<200; i++)
                            {
                                goclient[i]="-1";
                                dropclient[i]="-1";
                            }
                    }
                    //if he didnt get the job, he does nothing
                }
                
             
                                   

                 if(msg.getContent().contains("End"))//if message is to terminate
                    {
                           String[] rewarded=msg.getContent().split(","); 
                            reward=Integer.parseInt(rewarded[1]);//reward for agent
                            System.out.println(getLocalName()+" Final Reward: "+reward);
                            System.out.println(getLocalName()+" terminating");
                            //take down from registry
                            takeDown();
                            //terminate
                            doDelete();
                    }
              
                
        }

            
        });
    }
    
  public void getNodes(int x, int y)
    {
      
                start=x;
                goal=y;
                //converting int to String
                
                if(start==0 || start==1 || start==2 || start==3 || start==4)
                {
                    s= "0" + start;//s="00" || s="01" || s="02" || s="03" || s="04"
                }
                else
                {
                    s= "" + start;
                }  
                  
                
                
                if(goal==0 ||  goal==1 ||  goal==2 ||  goal==3 ||  goal==4)
                {
                    g= "0" + goal;//g="00" || g="01" || g="02" || g="03" || g="04"
                }
                 else
                {
                    g= "" + goal;
                }
                //div and mod for coordinates
                gy=goal%10;
                gx=goal/10;
                
                //creating nodes
                Node n1 = new Node("00",Math.abs(0-gx)+Math.abs(0-gy));
                Node n2 = new Node("01",Math.abs(0-gx)+Math.abs(1-gy));
                Node n3 = new Node("02",Math.abs(0-gx)+Math.abs(2-gy));
                Node n4 = new Node("03",Math.abs(0-gx)+Math.abs(3-gy));
                Node n5 = new Node("04",Math.abs(0-gx)+Math.abs(4-gy));
                Node n6 = new Node("10",Math.abs(1-gx)+Math.abs(0-gy));
                Node n7 = new Node("11",Math.abs(1-gx)+Math.abs(1-gy));
                Node n8 = new Node("12",Math.abs(1-gx)+Math.abs(2-gy));
                Node n9 = new Node("13",Math.abs(1-gx)+Math.abs(3-gy));
                Node n10 = new Node("14",Math.abs(1-gx)+Math.abs(4-gy));
                Node n11 = new Node("20",Math.abs(2-gx)+Math.abs(0-gy));
                Node n12 = new Node("21",Math.abs(2-gx)+Math.abs(1-gy));
                Node n13 = new Node("22",Math.abs(2-gx)+Math.abs(2-gy));
                Node n14 = new Node("23",Math.abs(2-gx)+Math.abs(3-gy));
                Node n15 = new Node("24",Math.abs(2-gx)+Math.abs(4-gy));
                Node n16 = new Node("30",Math.abs(3-gx)+Math.abs(0-gy));
                Node n17 = new Node("31",Math.abs(3-gx)+Math.abs(1-gy));
                Node n18 = new Node("32",Math.abs(3-gx)+Math.abs(2-gy));
                Node n19 = new Node("33",Math.abs(3-gx)+Math.abs(3-gy));
                Node n20 = new Node("34",Math.abs(3-gx)+Math.abs(4-gy));
                Node n21 = new Node("40",Math.abs(4-gx)+Math.abs(0-gy));
                Node n22 = new Node("41",Math.abs(4-gx)+Math.abs(1-gy));
                Node n23 = new Node("42",Math.abs(4-gx)+Math.abs(2-gy));
                Node n24 = new Node("43",Math.abs(4-gx)+Math.abs(3-gy));
                Node n25 = new Node("44",Math.abs(4-gx)+Math.abs(4-gy));
                //initialize the edges(neighbours)
                 //00
                n1.adjacencies = new Edge[]{
                    new Edge(n6,1),
                    new Edge(n2,100),
                        
                };
                 
                 //01
                n2.adjacencies = new Edge[]{
                    new Edge(n1,100),
                    new Edge(n3,1),
                    new Edge(n7,1)
                };
                 
                  //02
                n3.adjacencies = new Edge[]{
                    new Edge(n2,1),
                    new Edge(n4,100),
                    new Edge(n8,1)
                };
                 
                 //03
                n4.adjacencies = new Edge[]{                      
                    new Edge(n5,1),
                    new Edge(n3,100),
                    new Edge(n9,1),
                };
                 
                  //04
                n5.adjacencies = new Edge[]{
                    new Edge(n4,1),   
                    new Edge(n10,1)
                };
                 
                 //10
                n6.adjacencies = new Edge[]{
                    new Edge(n1,1),
                    new Edge(n7,100),
                    new Edge(n11,1)
                };
                 
                 //11
                n7.adjacencies = new Edge[]{
                    new Edge(n6,100),
                    new Edge(n2,1),
                    new Edge(n8,1),
                    new Edge(n12,1)
                };
                 
                 //12
                n8.adjacencies = new Edge[]{
                    new Edge(n7,1),
                    new Edge(n9,100),
                    new Edge(n3,1),
                    new Edge(n13,1)
                };
                 
                 //13
                n9.adjacencies = new Edge[]{
                    new Edge(n8,100),
                    new Edge(n10,1),
                    new Edge(n4,1),
                    new Edge(n14,1)
                };
                  //14
                n10.adjacencies = new Edge[]{
                    new Edge(n5,1),
                    new Edge(n9,1),
                    new Edge(n15,1)
                };
                 
                 //20
                n11.adjacencies = new Edge[]{
                    new Edge(n6,1),
                    new Edge(n12,1),
                    new Edge(n16,1),
                         
                };
                  //21
                n12.adjacencies = new Edge[]{
                    new Edge(n11,1),
                    new Edge(n13,1),
                    new Edge(n7,1),
                    new Edge(n17,1)
                };
                 //22
                n13.adjacencies = new Edge[]{
                    new Edge(n12,1),
                    new Edge(n14,1),
                    new Edge(n8,1),
                    new Edge(n18,1)
                };
                 
                 //23
                n14.adjacencies = new Edge[]{
                    new Edge(n13,1),
                    new Edge(n15,1),
                    new Edge(n19,1),
                    new Edge(n9,1)
                };
                //24
                n15.adjacencies = new Edge[]{
                    new Edge(n10,1),
                    new Edge(n20,1),
                    new Edge(n14,1),
                       
                };
                //30
                n16.adjacencies = new Edge[]{
                    new Edge(n17,1),
                    new Edge(n21,1),
                    new Edge(n11,1),
                       
                };
                //31
                n17.adjacencies = new Edge[]{
                    new Edge(n16,1),
                    new Edge(n22,1),
                    new Edge(n12,1),
                    new Edge(n18,100)
                };
                //32
                n18.adjacencies = new Edge[]{
                    new Edge(n17,100),
                    new Edge(n19,1),
                    new Edge(n23,1),
                    new Edge(n13,1)
                };
                //33
                n19.adjacencies = new Edge[]{
                    new Edge(n18,1),
                    new Edge(n20,1),
                    new Edge(n24,1),
                    new Edge(n14,1)
                };
                //34
                n20.adjacencies = new Edge[]{
                    new Edge(n19,1),
                    new Edge(n25,1),
                    new Edge(n15,1)
                       
                };
                //40
                n21.adjacencies = new Edge[]{
                    new Edge(n16,1),
                    new Edge(n22,1)
                      
                };
                //41
                n22.adjacencies = new Edge[]{
                    new Edge(n21,1),
                    new Edge(n17,1),
                    new Edge(n23,100)
                       
                };
                //42
                n23.adjacencies = new Edge[]{
                    new Edge(n22,100),
                    new Edge(n24,1),
                    new Edge(n18,1)
                      
                };
                //43
                n24.adjacencies = new Edge[]{
                    new Edge(n23,1),
                    new Edge(n25,1),
                    new Edge(n19,1)
                       
                };
                //44
                n25.adjacencies = new Edge[]{
                    new Edge(n24,1),
                    new Edge(n20,1)
                      
                };  
                
               //keeping which nodes are needed for A*
               //nodes is for starting point
               //nodeg is for destination
                if( s.equals(n1.value))
                {
                    nodes=n1;
                }if( s.equals(n2.value))
                {
                    nodes=n2;
                }
                if( s.equals(n3.value))
                {
                    nodes=n3;
                }
                if( s.equals(n4.value))
                {
                    nodes=n4;
                }
                if( s.equals(n5.value))
                {
                    nodes=n5;
                }
                 if( s.equals(n6.value))
                {
                    nodes=n6;                                       
                }
                 if( s.equals(n7.value))
                {
                    nodes=n7;                                       
                }
                 if( s.equals(n8.value))
                {
                    nodes=n8;                                       
                }
                 if( s.equals(n9.value))
                {
                    nodes=n9;                                       
                }
                 if( s.equals(n10.value))
                {
                    nodes=n10;                                       
                }
                 if( s.equals(n11.value))
                {
                    nodes=n11;                                       
                }
                 if( s.equals(n12.value))
                {
                    nodes=n12;                                       
                }
                 if( s.equals(n13.value))
                {
                    nodes=n13;                                       
                }
                 if( s.equals(n14.value))
                {
                    nodes=n14;                                       
                }
                 if( s.equals(n15.value))
                {
                    nodes=n15;                                       
                }
                 if( s.equals(n16.value))
                {
                    nodes=n16;                                       
                }
                 if( s.equals(n17.value))
                {
                    nodes=n17;                                       
                }
                 if( s.equals(n18.value))
                {
                    nodes=n18;                                       
                }
                 if( s.equals(n19.value))
                {
                    nodes=n19;                                       
                }
                 if( s.equals(n20.value))
                {
                    nodes=n20;                                       
                }
                 if( s.equals(n21.value))
                {
                    nodes=n21;                                       
                }
                 if( s.equals(n22.value))
                {
                    nodes=n22;                                       
                }
                 if( s.equals(n23.value))
                {
                    nodes=n23;                                       
                }
                 if( s.equals(n24.value))
                {
                    nodes=n24;                                       
                }
                 if( s.equals(n25.value))
                {
                    nodes=n25;                                       
                }
                //goal
                //nodeg is for destination
                if( g.equals(n1.value))
                {
                    nodeg=n1;
                }if( g.equals(n2.value))
                {
                    nodeg=n2;
                }
                if( g.equals(n3.value))
                {
                    nodeg=n3;
                }
                if( g.equals(n4.value))
                {
                    nodeg=n4;                 
                }
                if( g.equals(n5.value))
                {
                    nodeg=n5;  
                }
                 if( g.equals(n6.value))
                {
                    nodeg=n6;                                       
                }
                 if( g.equals(n7.value))
                {
                    nodeg=n7;                                       
                }
                 if( g.equals(n8.value))
                {
                    nodeg=n8;                                       
                }
                 if( g.equals(n9.value))
                {
                    nodeg=n9;                                       
                }
                 if( g.equals(n10.value))
                {
                    nodeg=n10;                                       
                }
                 if( g.equals(n11.value))
                {
                    nodeg=n11;                                       
                }
                 if( g.equals(n12.value))
                {
                    nodeg=n12;                                       
                }
                 if( g.equals(n13.value))
                {
                    nodeg=n13;                                       
                }
                 if( g.equals(n14.value))
                {
                    nodeg=n14;                                       
                }
                 if( g.equals(n15.value))
                {
                    nodeg=n15;                                       
                }
                 if( g.equals(n16.value))
                {
                    nodeg=n16;                                       
                }
                 if( g.equals(n17.value))
                {
                    nodeg=n17;                                       
                }
                 if( g.equals(n18.value))
                {
                    nodeg=n18;                                       
                }
                 if( g.equals(n19.value))
                {
                    nodeg=n19;                                       
                }
                 if( g.equals(n20.value))
                {
                    nodeg=n20;                                       
                }
                 if( g.equals(n21.value))
                {
                    nodeg=n21;                                       
                }
                 if( g.equals(n22.value))
                {
                    nodeg=n22;                                       
                }
                 if( g.equals(n23.value))
                {
                    nodeg=n23;                                       
                }
                 if( g.equals(n24.value))
                {
                    nodeg=n24;                                       
                }
                 if( g.equals(n25.value))
                {
                    nodeg=n25;                                       
                }
              
               
                AstarSearch(nodes,nodeg);//call A*
                List<Node> path = printPath(nodeg);//call to create paths and find heuristic
             
                
                
               
    }
    //creating path and inserting it in arrays
    public static List<Node> printPath(Node target)
    {
        List<Node> path = new ArrayList<Node>();
        steps=-1;//cost for agent
        for(Node node = target; node!=null; node = node.parent){
            path.add(node);
            
            
           steps++;
        }
        ar=path.size();
        if(fl==1)//if agent is going towards a client
        {
            heuclients[0]=steps;//keeping the cost
            fl=2;
            Collections.reverse(path);
            if(gclient!=-1)//flag to insert path to array
            {
            for(int i=0; i<ar; i++)
            {
            
            goclient[i]=String.valueOf(path.get(i));//inserting path to array
            }
            }
        }
        else if(fl==2)//if client is going to a destination to drop a client
        {
            heuclients[0]=steps+heuclients[0];//keeping the cost
            Collections.reverse(path);
            if(dclient!=-1)//flag to insert path to array
            {
            for(int i=0; i<ar; i++)
            {
            
            dropclient[i]=String.valueOf(path.get(i));//inserting path to array
            }
            }
            //client=client+1;
            fl=1;
        }
        
        
        
        
        return path;
    }
     
    //A*
     public static void AstarSearch(Node source, Node goal)
        {

                Set<Node> explored = new HashSet<Node>();

                PriorityQueue<Node> queue = new PriorityQueue<Node>(20, 
                        new Comparator<Node>(){
                                 //override compare method
                 public int compare(Node i, Node j){
                    if(i.f_scores > j.f_scores){
                        return 1;
                    }

                    else if (i.f_scores < j.f_scores){
                        return -1;
                    }

                    else{
                        return 0;
                    }
                 }

                        }
                        );

                //cost from start
                source.g_scores = 0;

                queue.add(source);

                boolean found = false;

                while((!queue.isEmpty())&&(!found)){

                        //the node in having the lowest f_score value
                        Node current = queue.poll();

                        explored.add(current);

                        //goal found
                        if(current.value.equals(goal.value)){
                                found = true;
                        }

                        //check every child of current node
                        for(Edge e : current.adjacencies){
                                Node child = e.target;
                                double cost = e.cost;
                                double temp_g_scores = current.g_scores + cost;
                                double temp_f_scores = temp_g_scores + child.h_scores;


                                //if child node has been evaluated and the newer f_score is higher, skip
                                if((explored.contains(child)) && (temp_f_scores >= child.f_scores)){
                                        continue;
                                }

                                //else if child node is not in queue or newer f_score is lower
                                else if((!queue.contains(child)) || (temp_f_scores < child.f_scores)){

                                        child.parent = current;
                                        child.g_scores = temp_g_scores;
                                        child.f_scores = temp_f_scores;

                                        if(queue.contains(child)){
                                                queue.remove(child);
                                        }

                                        queue.add(child);
                                          
                                }

                        }

                }

        }
    
    
    
}