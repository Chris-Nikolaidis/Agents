/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ergasia_taxi;

/**
 *
 * @author Χρήστος
 */
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.domain.FIPAException;
import jade.lang.acl.ACLMessage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Set;

public class Taxi extends Agent 
{
    public int reward=0;//save taxi's total reward
    public int done=0;//flag variable to check if all clients are done
    //variable used in converting String to Int and used in sending messages to grid
    public String go;
    //variables used in converting String positions to Int and are used in getNodes(int x, int y) as parameters
    public int x1;
    public int x2;
    public int x3;
    public static int ar;
    public String[] agentpos;//keeps taxi's position
    public String[] clientpos;//keeps clients starting position and destination
    public int min=800;//min, used to find best available client
    public int choose;//variable that keeps which client was chosen
    //variables used in getNodes(int x, int y)
    public  int start;
    public int goal;
    public int gx;
    public int gy;
    public String s;
    public String g;
    public Node nodes;
    public Node nodeg;
    //flag to check whether all clients have reached their destination
    public int end;
    //heuristic
    public  static int steps;//counts steps to go to client and drop him to the destination
    
    public static int[] heuclients =new int[200];//save every client's steps
    //flag variables
    public static int gclient=-1;
    public static int dclient=-1;
    public static int fl=1;
    public static int client;
    //arrays that keep paths
    public static String[] goclient =new String[200];//path from taxi to client
    public static String[] dropclient =new String[200];//path when taxi has client, to the destination
    
    
   
   
    public void setup() 
    {

        // register agent to directory facilitator
        DFAgentDescription dfd = new DFAgentDescription();
        // agent id
        dfd.setName(getAID());
        ServiceDescription sd = new ServiceDescription();
        sd.setType("agent");
        sd.setName(getLocalName());
        dfd.addServices(sd);
        try {DFService.register(this, dfd);}
        catch (FIPAException fe) {fe.printStackTrace();}

        addBehaviour(new CyclicBehaviour(this) {
        public void action() 
        {

                ACLMessage msg = null;
                //waiting to receive message
                msg = blockingReceive();
                //agent starting position
                if(msg.getContent().contains("TaxiStartingPos,"))
                {
                    //agent position is kept in agentpos[1]
                  String[] agentpos= msg.getContent().split(",");                                   
                  System.out.println("TaxiStartingPos");
                  System.out.println(agentpos[1]);
                  x1=Integer.parseInt(agentpos[1]);
                }
                //agent receives all clients(4) their starting positions and destinations
                else if(msg.getContent().contains("Client Position and Destination,"))
                {
                   String[] clientpos = msg.getContent().split(",");
                   System.out.println(clientpos[0]);
                    for(int i=0; i<clientpos.length; i++)
                    {  //printing all clients starting positions and destinations
                        if(i==0)
                        {
                        System.out.println("Client - 1");
                        }
                        if(i==3)
                        {
                            System.out.println("Client - 2");
                        }
                        if(i==5)
                        {
                            System.out.println("Client - 3");
                        }        
                        if(i==7)
                        {
                            System.out.println("Client - 4");
                        }
                        if(i!=0)
                        {
                            System.out.println(clientpos[i]);
                        }
                    }
                    //for that works 4 times. one for each client
                    for(int w=1; w<=4; w++)
                    {
                        end=w;
                        min=800;
                        gclient=-1;
                        dclient=-1;
                        
                        //emptying path arrays to avoid mistakes in pathing
                        for(int y=0; y<goclient.length; y++)
                        {
                            goclient[y]="-1";
                            dropclient[y]="-1";
                        }
                        //calculating paths for clients and finding the heuristic
                        for(int j=1; j<9; j+=2)
                        {
                            
                            int x4=j;
                            if(!"-1".equals(clientpos[x4]))//check to see whether the client has already been dropped
                            {
                                if(x4==1)
                                {
                                    client=1; 
                                }
                                if(x4==3)
                                {
                                    client=2; 
                                }
                                if(x4==5)
                                {
                                    client=3; 
                                }
                                if(x4==7)
                                {
                                    client=4; 
                                }
                                x2=Integer.parseInt(clientpos[j]);
                                x3=Integer.parseInt(clientpos[x4+1]);
                                getNodes(x1,x2);
                                getNodes(x2,x3);
                            }
                        }
                        //choosing best available client
                        for(int i=0; i<4; i++)
                        {
                            if(heuclients[i]<min)
                            {
                                min=heuclients[i];
                                choose=i+1;
                            }
                        }

                        gclient=0;
                        dclient=0;
                        ACLMessage message = new ACLMessage(ACLMessage.INFORM);
                        message.addReceiver(new AID("grid", AID.ISLOCALNAME));
                        //preparing message for grid informing which client was chosen
                            if(choose-1==0)
                            {
                                client=1;
                            x2=Integer.parseInt(clientpos[1]);
                            x3=Integer.parseInt(clientpos[2]);
                            getNodes(x1,x2);
                            getNodes(x2,x3);
                             message.setContent(choose+","+clientpos[1]+","+clientpos[2]);
                             clientpos[1]="-1";//client has been dropped, to know that it is done
                             clientpos[2]="-1";//client has been dropped, to know that it is done
                            }
                            if(choose-1==1)
                            {
                                client=2;
                            x2=Integer.parseInt(clientpos[3]);
                            x3=Integer.parseInt(clientpos[4]);
                            getNodes(x1,x2);
                            getNodes(x2,x3);
                            message.setContent(choose+","+clientpos[3]+","+clientpos[4]);
                            clientpos[3]="-1";//client has been dropped, to know that it is done
                            clientpos[4]="-1";//client has been dropped, to know that it is done
                            }
                            if(choose-1==2)
                            {
                                client=3;
                            x2=Integer.parseInt(clientpos[5]);
                            x3=Integer.parseInt(clientpos[6]);
                            getNodes(x1,x2);
                            getNodes(x2,x3);
                            message.setContent(choose+","+clientpos[5]+","+clientpos[6]);
                            clientpos[5]="-1";//client has been dropped, to know that it is done
                            clientpos[6]="-1";//client has been dropped, to know that it is done
                            }
                            if(choose-1==3)
                            {
                                client=4;
                            x2=Integer.parseInt(clientpos[7]);
                            x3=Integer.parseInt(clientpos[8]);
                            getNodes(x1,x2);
                            getNodes(x2,x3);
                            message.setContent(choose+","+clientpos[7]+","+clientpos[8]);
                            clientpos[7]="-1";//client has been dropped, to know that it is done
                            clientpos[8]="-1";//client has been dropped, to know that it is done
                            }
                            heuclients[choose-1]=800;////client has been dropped, to know that it is done and not use this heuristic
                            send(message);
                            

                        //here starts the movement of the taxi    
                        //agent moving towards the client for pickup  
                        for(int i=1; i<goclient.length; i++)
                        {
                            if(!"-1".equals(goclient[i]))//if array isn't empty
                            {
                            go = goclient[i];
                            x1=Integer.parseInt(goclient[i]);
                            }
                            if("-1".equals(goclient[i]))//if array empty
                            {
                              go="pickup";  
                            }
                            if("pickup".equals(go))//if array empty get out of for
                            {
                                i=250;
                            }
                            message = new ACLMessage(ACLMessage.INFORM);
                            message.addReceiver(new AID("grid", AID.ISLOCALNAME));
                            message.setContent(go+","+done);
                            send(message);//sending message

                        }
                       //agent moving with the client to the destination to drop the client  
                        for(int i=1; i<dropclient.length; i++)
                        {
                            if(!"-1".equals(dropclient[i]))//if array isn't empty
                            {
                            go = dropclient[i];
                            x1=Integer.parseInt(dropclient[i]);
                            }
                            if("-1".equals(dropclient[i]))//if array is empty
                            {
                              go="drop";
                              if(end==4)//if this is the last client inform the grid
                              {
                              done=1;
                              }
                            }
                            if("drop".equals(go))//if array empty get out of for
                            {
                                i=250;
                            }
                            message = new ACLMessage(ACLMessage.INFORM);
                            message.addReceiver(new AID("grid", AID.ISLOCALNAME));
                            message.setContent(go+","+done);
                            send(message);//send message

                        }
                    }//clients have been successfully dropped to their destination
                    //waiting for message from grid terminating and getting the reward
                    ACLMessage msg1 = null;
                    //waiting to receive message
                    msg1 = blockingReceive();
                    if(msg1.getContent().contains("End"))//if message is to terminate
                    {
                           String[] rewarded=msg1.getContent().split(","); 
                            reward=Integer.parseInt(rewarded[1]);//reward for agent
                            System.out.println(getLocalName()+" Final Reward: "+reward);
                            System.out.println(getLocalName()+" terminating");
                            //take down from registry
                            takeDown();
                            //terminate
                            doDelete();
                    }
                    
                   
                   
                }
                
              
                
        }

            
        });
    }
    
  public void getNodes(int x, int y)
    {
      
                start=x;
                goal=y;
                //converting int to String
                
                if(start==0 || start==1 || start==2 || start==3 || start==4)
                {
                    s= "0" + start;//s="00" || s="01" || s="02" || s="03" || s="04"
                }
                else
                {
                    s= "" + start;
                }  
                  
                
                
                if(goal==0 ||  goal==1 ||  goal==2 ||  goal==3 ||  goal==4)
                {
                    g= "0" + goal;//g="00" || g="01" || g="02" || g="03" || g="04"
                }
                 else
                {
                    g= "" + goal;
                }
                //div and mod for coordinates
                gy=goal%10;
                gx=goal/10;
                
                //creating nodes
                Node n1 = new Node("00",Math.abs(0-gx)+Math.abs(0-gy));
                Node n2 = new Node("01",Math.abs(0-gx)+Math.abs(1-gy));
                Node n3 = new Node("02",Math.abs(0-gx)+Math.abs(2-gy));
                Node n4 = new Node("03",Math.abs(0-gx)+Math.abs(3-gy));
                Node n5 = new Node("04",Math.abs(0-gx)+Math.abs(4-gy));
                Node n6 = new Node("10",Math.abs(1-gx)+Math.abs(0-gy));
                Node n7 = new Node("11",Math.abs(1-gx)+Math.abs(1-gy));
                Node n8 = new Node("12",Math.abs(1-gx)+Math.abs(2-gy));
                Node n9 = new Node("13",Math.abs(1-gx)+Math.abs(3-gy));
                Node n10 = new Node("14",Math.abs(1-gx)+Math.abs(4-gy));
                Node n11 = new Node("20",Math.abs(2-gx)+Math.abs(0-gy));
                Node n12 = new Node("21",Math.abs(2-gx)+Math.abs(1-gy));
                Node n13 = new Node("22",Math.abs(2-gx)+Math.abs(2-gy));
                Node n14 = new Node("23",Math.abs(2-gx)+Math.abs(3-gy));
                Node n15 = new Node("24",Math.abs(2-gx)+Math.abs(4-gy));
                Node n16 = new Node("30",Math.abs(3-gx)+Math.abs(0-gy));
                Node n17 = new Node("31",Math.abs(3-gx)+Math.abs(1-gy));
                Node n18 = new Node("32",Math.abs(3-gx)+Math.abs(2-gy));
                Node n19 = new Node("33",Math.abs(3-gx)+Math.abs(3-gy));
                Node n20 = new Node("34",Math.abs(3-gx)+Math.abs(4-gy));
                Node n21 = new Node("40",Math.abs(4-gx)+Math.abs(0-gy));
                Node n22 = new Node("41",Math.abs(4-gx)+Math.abs(1-gy));
                Node n23 = new Node("42",Math.abs(4-gx)+Math.abs(2-gy));
                Node n24 = new Node("43",Math.abs(4-gx)+Math.abs(3-gy));
                Node n25 = new Node("44",Math.abs(4-gx)+Math.abs(4-gy));
                //initialize the edges(neighbours)
                 //00
                n1.adjacencies = new Edge[]{
                    new Edge(n6,1),
                    new Edge(n2,100),
                        
                };
                 
                 //01
                n2.adjacencies = new Edge[]{
                    new Edge(n1,100),
                    new Edge(n3,1),
                    new Edge(n7,1)
                };
                 
                  //02
                n3.adjacencies = new Edge[]{
                    new Edge(n2,1),
                    new Edge(n4,100),
                    new Edge(n8,1)
                };
                 
                 //03
                n4.adjacencies = new Edge[]{                      
                    new Edge(n5,1),
                    new Edge(n3,100),
                    new Edge(n9,1),
                };
                 
                  //04
                n5.adjacencies = new Edge[]{
                    new Edge(n4,1),   
                    new Edge(n10,1)
                };
                 
                 //10
                n6.adjacencies = new Edge[]{
                    new Edge(n1,1),
                    new Edge(n7,100),
                    new Edge(n11,1)
                };
                 
                 //11
                n7.adjacencies = new Edge[]{
                    new Edge(n6,100),
                    new Edge(n2,1),
                    new Edge(n8,1),
                    new Edge(n12,1)
                };
                 
                 //12
                n8.adjacencies = new Edge[]{
                    new Edge(n7,1),
                    new Edge(n9,100),
                    new Edge(n3,1),
                    new Edge(n13,1)
                };
                 
                 //13
                n9.adjacencies = new Edge[]{
                    new Edge(n8,100),
                    new Edge(n10,1),
                    new Edge(n4,1),
                    new Edge(n14,1)
                };
                  //14
                n10.adjacencies = new Edge[]{
                    new Edge(n5,1),
                    new Edge(n9,1),
                    new Edge(n15,1)
                };
                 
                 //20
                n11.adjacencies = new Edge[]{
                    new Edge(n6,1),
                    new Edge(n12,1),
                    new Edge(n16,1),
                         
                };
                  //21
                n12.adjacencies = new Edge[]{
                    new Edge(n11,1),
                    new Edge(n13,1),
                    new Edge(n7,1),
                    new Edge(n17,1)
                };
                 //22
                n13.adjacencies = new Edge[]{
                    new Edge(n12,1),
                    new Edge(n14,1),
                    new Edge(n8,1),
                    new Edge(n18,1)
                };
                 
                 //23
                n14.adjacencies = new Edge[]{
                    new Edge(n13,1),
                    new Edge(n15,1),
                    new Edge(n19,1),
                    new Edge(n9,1)
                };
                //24
                n15.adjacencies = new Edge[]{
                    new Edge(n10,1),
                    new Edge(n20,1),
                    new Edge(n14,1),
                       
                };
                //30
                n16.adjacencies = new Edge[]{
                    new Edge(n17,1),
                    new Edge(n21,1),
                    new Edge(n11,1),
                       
                };
                //31
                n17.adjacencies = new Edge[]{
                    new Edge(n16,1),
                    new Edge(n22,1),
                    new Edge(n12,1),
                    new Edge(n18,100)
                };
                //32
                n18.adjacencies = new Edge[]{
                    new Edge(n17,100),
                    new Edge(n19,1),
                    new Edge(n23,1),
                    new Edge(n13,1)
                };
                //33
                n19.adjacencies = new Edge[]{
                    new Edge(n18,1),
                    new Edge(n20,1),
                    new Edge(n24,1),
                    new Edge(n14,1)
                };
                //34
                n20.adjacencies = new Edge[]{
                    new Edge(n19,1),
                    new Edge(n25,1),
                    new Edge(n15,1)
                       
                };
                //40
                n21.adjacencies = new Edge[]{
                    new Edge(n16,1),
                    new Edge(n22,1)
                      
                };
                //41
                n22.adjacencies = new Edge[]{
                    new Edge(n21,1),
                    new Edge(n17,1),
                    new Edge(n23,100)
                       
                };
                //42
                n23.adjacencies = new Edge[]{
                    new Edge(n22,100),
                    new Edge(n24,1),
                    new Edge(n18,1)
                      
                };
                //43
                n24.adjacencies = new Edge[]{
                    new Edge(n23,1),
                    new Edge(n25,1),
                    new Edge(n19,1)
                       
                };
                //44
                n25.adjacencies = new Edge[]{
                    new Edge(n24,1),
                    new Edge(n20,1)
                      
                };  
                
               //keeping which nodes are needed for A*
               //nodes is for starting point
               //nodeg is for destination
                if( s.equals(n1.value))
                {
                    nodes=n1;
                }if( s.equals(n2.value))
                {
                    nodes=n2;
                }
                if( s.equals(n3.value))
                {
                    nodes=n3;
                }
                if( s.equals(n4.value))
                {
                    nodes=n4;
                }
                if( s.equals(n5.value))
                {
                    nodes=n5;
                }
                 if( s.equals(n6.value))
                {
                    nodes=n6;                                       
                }
                 if( s.equals(n7.value))
                {
                    nodes=n7;                                       
                }
                 if( s.equals(n8.value))
                {
                    nodes=n8;                                       
                }
                 if( s.equals(n9.value))
                {
                    nodes=n9;                                       
                }
                 if( s.equals(n10.value))
                {
                    nodes=n10;                                       
                }
                 if( s.equals(n11.value))
                {
                    nodes=n11;                                       
                }
                 if( s.equals(n12.value))
                {
                    nodes=n12;                                       
                }
                 if( s.equals(n13.value))
                {
                    nodes=n13;                                       
                }
                 if( s.equals(n14.value))
                {
                    nodes=n14;                                       
                }
                 if( s.equals(n15.value))
                {
                    nodes=n15;                                       
                }
                 if( s.equals(n16.value))
                {
                    nodes=n16;                                       
                }
                 if( s.equals(n17.value))
                {
                    nodes=n17;                                       
                }
                 if( s.equals(n18.value))
                {
                    nodes=n18;                                       
                }
                 if( s.equals(n19.value))
                {
                    nodes=n19;                                       
                }
                 if( s.equals(n20.value))
                {
                    nodes=n20;                                       
                }
                 if( s.equals(n21.value))
                {
                    nodes=n21;                                       
                }
                 if( s.equals(n22.value))
                {
                    nodes=n22;                                       
                }
                 if( s.equals(n23.value))
                {
                    nodes=n23;                                       
                }
                 if( s.equals(n24.value))
                {
                    nodes=n24;                                       
                }
                 if( s.equals(n25.value))
                {
                    nodes=n25;                                       
                }
                //goal
                //nodeg is for destination
                if( g.equals(n1.value))
                {
                    nodeg=n1;
                }if( g.equals(n2.value))
                {
                    nodeg=n2;
                }
                if( g.equals(n3.value))
                {
                    nodeg=n3;
                }
                if( g.equals(n4.value))
                {
                    nodeg=n4;                 
                }
                if( g.equals(n5.value))
                {
                    nodeg=n5;  
                }
                 if( g.equals(n6.value))
                {
                    nodeg=n6;                                       
                }
                 if( g.equals(n7.value))
                {
                    nodeg=n7;                                       
                }
                 if( g.equals(n8.value))
                {
                    nodeg=n8;                                       
                }
                 if( g.equals(n9.value))
                {
                    nodeg=n9;                                       
                }
                 if( g.equals(n10.value))
                {
                    nodeg=n10;                                       
                }
                 if( g.equals(n11.value))
                {
                    nodeg=n11;                                       
                }
                 if( g.equals(n12.value))
                {
                    nodeg=n12;                                       
                }
                 if( g.equals(n13.value))
                {
                    nodeg=n13;                                       
                }
                 if( g.equals(n14.value))
                {
                    nodeg=n14;                                       
                }
                 if( g.equals(n15.value))
                {
                    nodeg=n15;                                       
                }
                 if( g.equals(n16.value))
                {
                    nodeg=n16;                                       
                }
                 if( g.equals(n17.value))
                {
                    nodeg=n17;                                       
                }
                 if( g.equals(n18.value))
                {
                    nodeg=n18;                                       
                }
                 if( g.equals(n19.value))
                {
                    nodeg=n19;                                       
                }
                 if( g.equals(n20.value))
                {
                    nodeg=n20;                                       
                }
                 if( g.equals(n21.value))
                {
                    nodeg=n21;                                       
                }
                 if( g.equals(n22.value))
                {
                    nodeg=n22;                                       
                }
                 if( g.equals(n23.value))
                {
                    nodeg=n23;                                       
                }
                 if( g.equals(n24.value))
                {
                    nodeg=n24;                                       
                }
                 if( g.equals(n25.value))
                {
                    nodeg=n25;                                       
                }
              
               
                AstarSearch(nodes,nodeg);//call A*
                List<Node> path = printPath(nodeg);//call to create paths and find heuristic
             
                
                
               
    }
    //creating path and inserting it in arrays
    public static List<Node> printPath(Node target)
    {
        List<Node> path = new ArrayList<Node>();
        steps=-1;//cost for agent
        for(Node node = target; node!=null; node = node.parent){
            path.add(node);
            
            
           steps++;
        }
        ar=path.size();
        if(fl==1)//if agent is going towards a client
        {
            heuclients[client-1]=steps;//keeping the cost
            fl=2;
            Collections.reverse(path);
            if(gclient!=-1)//flag to insert path to array
            {
            for(int i=0; i<ar; i++)
            {
            
            goclient[i]=String.valueOf(path.get(i));//inserting path to array
            }
            }
        }
        else if(fl==2)//if client is going to a destination to drop a client
        {
            heuclients[client-1]=steps+heuclients[client-1];//keeping the cost
            Collections.reverse(path);
            if(dclient!=-1)//flag to insert path to array
            {
            for(int i=0; i<ar; i++)
            {
            
            dropclient[i]=String.valueOf(path.get(i));//inserting path to array
            }
            }
            //client=client+1;
            fl=1;
        }
        
        
        
        
        return path;
    }
     
    //A*
     public static void AstarSearch(Node source, Node goal)
        {

                Set<Node> explored = new HashSet<Node>();

                PriorityQueue<Node> queue = new PriorityQueue<Node>(20, 
                        new Comparator<Node>(){
                                 //override compare method
                 public int compare(Node i, Node j){
                    if(i.f_scores > j.f_scores){
                        return 1;
                    }

                    else if (i.f_scores < j.f_scores){
                        return -1;
                    }

                    else{
                        return 0;
                    }
                 }

                        }
                        );

                //cost from start
                source.g_scores = 0;

                queue.add(source);

                boolean found = false;

                while((!queue.isEmpty())&&(!found)){

                        //the node in having the lowest f_score value
                        Node current = queue.poll();

                        explored.add(current);

                        //goal found
                        if(current.value.equals(goal.value)){
                                found = true;
                        }

                        //check every child of current node
                        for(Edge e : current.adjacencies){
                                Node child = e.target;
                                double cost = e.cost;
                                double temp_g_scores = current.g_scores + cost;
                                double temp_f_scores = temp_g_scores + child.h_scores;


                                //if child node has been evaluated and the newer f_score is higher, skip
                                if((explored.contains(child)) && (temp_f_scores >= child.f_scores)){
                                        continue;
                                }

                                //else if child node is not in queue or newer f_score is lower
                                else if((!queue.contains(child)) || (temp_f_scores < child.f_scores)){

                                        child.parent = current;
                                        child.g_scores = temp_g_scores;
                                        child.f_scores = temp_f_scores;

                                        if(queue.contains(child)){
                                                queue.remove(child);
                                        }

                                        queue.add(child);
                                          
                                }

                        }

                }

        }
    
    
    
}