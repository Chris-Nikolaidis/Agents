/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ergasia_taxi;

/**
 *
 * @author Χρήστος
 */

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.domain.FIPAException;
import jade.lang.acl.ACLMessage;
import java.util.Arrays;
import java.util.Random;


public class Environment extends Agent {
private int clients=0;// 4 clients in the environment

private String[] agentArray;//array with all agents
private int numberOfAgents;
//variables for getting taxi starting pos
public int tx;
public int ty;
public int pos;//taxi position
public int move=0;//flag variable
public int reward;//cost for the taxi
public int treward;//total reward for taxi
public int[] client= new int[10];//clients starting position and destination
public String [] clientchoose;//array that states which client was chosen by the taxi
 public void setup()
	{

        try {Thread.sleep(50);} catch (InterruptedException ie) {}      //important
        //search the registry for agents
        DFAgentDescription template = new DFAgentDescription();
        ServiceDescription sd = new ServiceDescription();
        sd.setType("agent");
        template.addServices(sd);
        try {
            DFAgentDescription[] result = DFService.search(this, template);
            numberOfAgents = result.length;
            agentArray = new String[numberOfAgents];
            for (int i = 0; i < numberOfAgents; ++i) {
                agentArray[i] = result[i].getName().getLocalName();
            }
        }
        catch (FIPAException fe) {fe.printStackTrace();}
        Arrays.sort(agentArray);
        System.out.println("Found:");
        for (int i = 0; i < numberOfAgents; ++i) System.out.println(agentArray[i]);
        findStartingLocations();//random starting position for taxi
		
		
		
		addBehaviour(new CyclicBehaviour(this) {
            public void action(){
				int xx=-2;//flag variable
                                int yy=-2;//flag variable
				int clientstart;//client starting position
				int clientdest;//client destination
                                int flag=0;//flag variable 
                                try {Thread.sleep(50);} catch (InterruptedException ie) {}//wait
                                if(clients<4)//if not all clients have been dropped
                                {    
				//sending starting position and destination of 4 clients
                                    for (String agentName: agentArray) 
                                    {
                                        for (int i = 0; i < 8; i=i+2)//for creating 2 positions(starting and destination) for each client
                                        {
                                            while(flag==0)//check if position is 00 or 03 or 40 or 44 were randomly generated
                                            {
                                                xx=(int)(Math.random()*((5-0)))+0;//random number from 0 to 4
                                                yy=(int)(Math.random()*((5-0)))+0;//random number from 0 to 4
                                                if(xx==0 && yy==0)//00
                                                {
                                                    flag=1;//end while
                                                }
                                                if(xx==0 && yy==3)//03
                                                {
                                                    flag=1;//end while
                                                }
                                                if(xx==4 && yy==0)//40
                                                {
                                                    flag=1;//end while
                                                }
                                                if(xx==4 && yy==4)//44
                                                {
                                                    flag=1;//end while
                                                }
                                            }
                                            flag=0;
                                            clientstart=xx*10+yy;//client starting pos
                                            while(flag==0)//check if position is 00 or 03 or 40 or 44 were randomly generated
                                            {
                                               xx=(int)(Math.random()*((5-0)))+0;//random number from 0 to 4
                                                yy=(int)(Math.random()*((5-0)))+0;//random number from 0 to 4
                                                if(xx==0 && yy==0)//00
                                                {
                                                    flag=1;//end while
                                                }
                                                if(xx==0 && yy==3)//03
                                                {
                                                    flag=1;//end while
                                                }
                                                if(xx==4 && yy==0)//40
                                                {
                                                    flag=1;//end while
                                                }
                                                if(xx==4 && yy==4)//44
                                                {
                                                    flag=1;//end while
                                                } 
                                            }
                                            clientdest=xx*10+yy;//client destination
                                            //keeping each clients coords in array
                                            client[i]=clientstart;
                                            client[i+1]=clientdest;
                                            flag=0;
                                        }
                                        ACLMessage message = new ACLMessage(ACLMessage.INFORM);
                                        //refer to receiver by local name
                                        message.addReceiver(new AID(agentName, AID.ISLOCALNAME));
                                        //sending message with all client positions and destinations
                                        message.setContent("Client Position and Destination,"+client[0]+","+client[1]+","+client[2]+","+client[3]+","+client[4]+","+client[5]+","+client[6]+","+client[7]);
                                        send(message);//informing taxi with all clients
                                    }
                                    //taxi sends message declaring which client was chosen	
                                    for (int i = 0; i < numberOfAgents; i++) 
                                    {
                                        ACLMessage msg = null;
                                        msg = blockingReceive();
                                        String senderName = msg.getSender().getLocalName();
                                        String[] clientchoose = msg.getContent().split(",");
                                        System.out.println("Taxi current position: "+pos);
                                        System.out.println("Taxi choose client-"+clientchoose[0]+".Client Starting Pos: "+clientchoose[1]+" Client Dest: "+clientchoose[2]);

                                    }
                                    //taxi sends message updating its movements and whereabouts
                                    for (int i = 0; i < numberOfAgents; i++) 
                                    {
                                        while(move==0)//check whether all clients have been dropped to their destination
                                        {
                                            ACLMessage msg = null;
                                            msg = blockingReceive();
                                            String[] move1 = msg.getContent().split(",");
                                            String senderName = msg.getSender().getLocalName();
                                            //check if taxi is telling which client was chosen or telling about its movements
                                            if(move1.length>2)//taxi chose a client
                                            {
                                                //printing taxi's current position
                                                if(pos==0 || pos==1 || pos==2 || pos==3 || pos==4)
                                                {
                                                    
                                                System.out.println("Taxi current position: 0"+pos);
                                                }
                                                else
                                                {
                                                    System.out.println("Taxi current position: "+pos);
                                                }
                                                //printing which client was chosen
                                                if(Integer.parseInt(move1[0])==1)
                                                {
                                                        System.out.println("Taxi choose client-"+move1[0]+".Client Starting Pos: "+client[0]+" Client Dest: "+client[1]);
                                                }
                                                if(Integer.parseInt(move1[0])==2)
                                                {
                                                        System.out.println("Taxi choose client-"+move1[0]+".Client Starting Pos: "+client[2]+" Client Dest: "+client[3]);
                                                }
                                                if(Integer.parseInt(move1[0])==3)
                                                {
                                                        System.out.println("Taxi choose client-"+move1[0]+".Client Starting Pos: "+client[4]+" Client Dest: "+client[5]);
                                                }
                                                if(Integer.parseInt(move1[0])==4)
                                                {
                                                        System.out.println("Taxi choose client-"+move1[0]+".Client Starting Pos: "+client[6]+" Client Dest: "+client[7]);
                                                }
                                              
                                            }
                                            else//taxi informing about its movements
                                            { 
                                                switch (move1[0]) //check to update taxi's current position
                                                {
                                                    case "pickup":
                                                        break;
                                                    case "drop":
                                                        break;
                                                    default:
                                                        pos=Integer.parseInt(move1[0]);
                                                        break;
                                                }
                                                System.out.println(senderName + " moved to: " + move1[0]);
                                                reward=reward+1;//update cost for taxi
                                           
                                                if("1".equals(move1[1]))//check if done with all clients
                                                {
                                                    if(pos==0 || pos==1 || pos==2 || pos==3 || pos==4)
                                                    {
                                                    System.out.println("Taxi Final position: 0"+pos);
                                                    }
                                                    else
                                                    {
                                                        System.out.println("Taxi Final position: "+pos);
                                                    }
                                                    move=1;//flag to get out of while
                                                    System.out.println("Done. All clients have been successfully dropped off to their destinations. ");
                                                }
                                                if("drop".equals(move1[0]))//each time taxi drops a client and goes to the next
                                                {

                                                    clients=clients+1;

                                                }
                                            }  
                                           
                                        }

                                    }
                                }
                                else//if all 4 clients are done
                                {
                                    for (String agentName: agentArray) 
                                    {
                                        ACLMessage messageFinal = new ACLMessage(ACLMessage.INFORM);
                                        messageFinal.addReceiver(new AID(agentName, AID.ISLOCALNAME));
                                        treward=80-reward;//calculate reward for taxi and send it
                                        messageFinal.setContent("End"+","+treward);
                                        send(messageFinal);

                                        System.out.println("Total Cost: "+reward);
                                        //System.out.println("Final reward: "+treward);
                                        System.out.println(getLocalName()+" terminating");
                                        System.out.println("Good Job Everyone.");
                                        doDelete();
                                        System.exit(0);
                                    }
                                } 
		}		
		});

	}
	
	
	
    public void findStartingLocations()//randomly generated starting position for taxi
    {

        try {Thread.sleep(50);} catch (InterruptedException ie) {}

	for (String agentName: agentArray) 
	{
             tx =(int)(Math.random()*((5-0)))+0;//random number from 0 to 4
             ty=(int)(Math.random()*((5-0)))+0;//random number from 0 to 4
              pos=tx*10+ty;//agent position
             ACLMessage message = new ACLMessage(ACLMessage.INFORM);
             //refer to receiver by local name
             message.addReceiver(new AID(agentName, AID.ISLOCALNAME));
             
             message.setContent("TaxiStartingPos,"+pos);
             
             send(message);
        }
    }
}

